#ifndef _LAB2_H_
#define _LAB2_H_
#include <iostream>
#include <forward_list>
#include "lab2.h"
#include <string>
#include <stdlib.h>
#include <vector>

using namespace std;

//this is for part 1
bool isPrime(int i )
{
    if(i <= 2)//checks to see vals less than 2 since for loop doesnt account for those
    {
        if(i <= 0)
        {
            return false;
        }
        if(i == 1)
        {
            return false;
        }
        if(i == 2)
        {
            return true;
        }
    }
    for(int x = 2; x < i; x++)
    {
        if(i%x == 0)//if there is no remainder than the number i must be divisble by some x
        {
            return false;//if divisble by some x it is not a prime
        }
    }
    return true;
}

int primeCount(forward_list <int> only)
{
    if (only.empty()) // checks an emtpy list
    {
        return 0;
    }

    int primeC = 0;
    forward_list<int>::iterator it = only.begin();
    if(it != only.end())
    {
      if(isPrime(*it))
      {
          primeC++;//in each recursive call primeC will only ever be as high as 1
      }
      only.pop_front();
      return primeC + primeCount(only);//recursive call
    }
    else if(it == only.end())//ends the recursive loop when the end is reached
    {
      if(isPrime(*it))
      {
          return 1;
      }
      return 0;
    }
    return primeC;
}

//This is for part 2
template <typename T>
struct Node
{
    T data;
    Node *next;
    Node(T data) : data(data), next(0) {}
};

template <class T>
class List
{
    private: 
      Node <T> *head;
    public:
      List();
      ~List();
      void push_front(T value);
      void display();
      void elementSwap(int pos);
};

template <class T>
List<T>::List()
{
    head = 0;
}

template <class T>
List<T>::~List()
{
    if(head == 0)//dont delete if there are no nodes
    {
        return;
    }
    Node<T> *curr = head;
    Node<T> *rem = head;
    for(curr = head; curr != 0; curr = curr->next)//deletes all the middle nodes
    {
        if(curr != rem)
        {
            delete rem;
            rem = curr;
        }
    }
    delete head;//gets rid of the the 2 endpoint nodes
    delete curr;
}

template <class T>
void List<T>::push_front(T value)//used to enter in new nodes
{
    Node <T> *temp = new Node<T>(value);
    temp->next = head;
    head = temp;
}

template <class T>
void List<T>::display()
{
    if (head == 0) //sees if it is an empty list
    {
        cout << "Nothing to display";
        return;
    }
    
    Node <T> *curr = head; // this node will traverse the list
    
    while (curr != 0) // goes until the end and displays all the values
    {
        cout << curr->data<< " ";
        curr = curr->next;
    }
    cout << endl;
}

template <class T>
void List<T>::elementSwap( int pos )
{
    if(head == 0)
    {
        return;
    }
    
    int size = 0;
    for(Node<T>* n = head; n != 0; n = n->next)
    {
        size++;
    }
    
    if (size <= pos + 1 || pos < 0) // if pos is the size, error at pos + 1
    {
        cout << "You have gone beyond the bound." << endl;
        return;
    }
    
    if(pos == 0)//if at pos 0 only need to handle 3 temps
    {
        Node<T>* temp1 = head;
        Node<T>* temp2 = temp1->next;
        Node<T>* temp3 = temp2->next;
        temp2->next = temp1;
        temp1->next = temp3;
        head = temp2;
        return;
    }
    
    Node<T>* temp1 = head;//for when pos does not equal 0
    Node<T>* temp2;
    Node<T>* temp3;
    Node<T>* temp4;
    
    for(int i = 0; i < pos - 1; i++)//temp1 is at location pos - 1
    {
        temp1 = temp1->next;
    }
    temp2 = temp1->next;
    temp3 = temp2->next;
    temp4 = temp3->next;
    temp1->next = temp3;//makes sure the previous pointer before postion points to the right next node
    temp3->next = temp2;
    temp2->next = temp4;
} 

//this is for part 3
template <typename T>
void listCopy( forward_list <T> L, forward_list <T> &P)
{
    vector <T> temp1;
    vector <T> temp2;


    for(typename forward_list<T>::iterator i = L.begin();
    i != L.end();i++)
    {
        temp1.push_back(*i);
    }

    int x = temp1.size() -1;
    for(typename forward_list<T>::iterator i = L.begin();//puts the vals in reverse order in list L
    i != L.end();i++)
    {
        *i = temp1.at(x);
        x--;
    }

    for(typename forward_list<T>::iterator i = P.begin();
    i != P.end();i++)
    {
        temp2.push_back(*i);
    }

    int y = temp2.size() -1;
    for(typename forward_list<T>::iterator i = P.begin();//puts the vals in reverse order in list P
    i != P.end();i++) //i do this so when i push_front, P will be in order
    {
        *i = temp2.at(y);
        y--;
    }

    for(typename forward_list<T>::iterator i = P.begin();
    i != P.end();i++)
    {
        L.push_front(*i);
    }

    P = L;

    for(typename forward_list<T>::iterator i = P.begin();//prints the values of p for error checking
    i != P.end();i++)
    {
        cout << *i << " ";
    }
    cout << endl;
}

//this is for part 4
template <typename T>
void printLots (forward_list <T> L, forward_list <int> P)
{
    int size =0;
    int greatN = 0;

    for(typename forward_list <T>::iterator it //gets size of L
    = L.begin(); it != L.end(); ++it)
    {
        size++;
    }
    for(forward_list<int>::iterator f
    = P.begin(); f != P.end(); f++)
    {
        greatN = *f;//since P is in ascending order, greatN will be the greatest number in P
    }
    if(size <= greatN)//checks to see if the int list goes to a number higher than the size of P
    {
        cout << "The int forward list goes out of bounds."
        << endl;
        return;
    }

    int i = 0;
    forward_list<int>::iterator q = P.begin();
    for(typename forward_list <T>::iterator it
    = L.begin(); it != L.end(); ++it)
    {
        if(i == *q)
        {
            cout << *it << " ";//prints the data at the iterator specified by the int list
            q++;
        }
        if(q == P.end())//if q is at the end of the P list, then you dont have to search anymore
        {
            cout << endl;
            return;//exits the search
        }
        i++;
    }
    cout << endl;
}

#endif