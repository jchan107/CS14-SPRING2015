//Name: Jeremy Chan SID: 861169589 date: 4/19/2015
//Lecturer: Jacobs Lab Director: Dingwen

#include "lab2.h"
#include <stdlib.h>
#include <iostream>
#include <forward_list>
#include <vector>
#include <stdlib.h>

int main ()
{
    cout << "Part Number 1." << endl;
    forward_list<int> l1 = {2,4,7,6,4,2,23};
    cout<< "Prime count (2,4,7,6,4,2,23): " << primeCount(l1) << endl;
    forward_list<int> l2 = {1,3,53,23,17,13};
    cout<< "Prime count (1,3,53,23,17,13): " << primeCount(l2) << endl;
    cout << endl;
    
    cout << "Part Number 2." << endl;
    cout << "Now using the list class: pushing front once " <<
    "and displaying (7)" << endl;
    List<int> l7;
    l7.push_front(7);
    l7.display();
    cout << "Now trying element swap at index 0 (error): " << endl;
    l7.elementSwap(0);
    cout << "Now using the list class: pushing front multiple times " <<
    "and displaying (2,5,8,1,5,4,7)" << endl;
    l7.push_front(4);
    l7.push_front(5);
    l7.push_front(1);
    l7.push_front(8);
    l7.push_front(5);
    l7.push_front(2);
    l7.display();
    cout << "Now trying element swap at index 1: " << endl;
    l7.elementSwap(1);
    l7.display();
    cout << "Now trying element swap at index 6: (error) " << endl;
    l7.elementSwap(6);
    l7.display();cout << "Now trying element swap at index 5: " << endl;
    l7.elementSwap(5);
    l7.display();cout << "Now trying element swap at index 0: " << endl;
    l7.elementSwap(0);
    l7.display();
    cout << endl;
    
    cout << "Part Number 3." << endl;
    forward_list<int> l5 = {10,9,8,7,6};
    forward_list<int> l6 = {1,2,3,4,5};
    cout << "The two lists for list copy: " <<endl <<
    "(10,9,8,7,6)" << endl << "(1,2,3,4,5)" << endl;
    cout << "The list copied: ";
    listCopy(l5,l6);
    forward_list<int> l10 = {};
    forward_list<int> l11 = {1,2,3,4,5};
    cout << "The two lists for list copy: " <<endl <<
    "(no numbers)" << endl << "(1,2,3,4,5)" << endl;
    cout << "The list copied: ";
    listCopy(l10,l11);
    forward_list<int> l12 = {10,9,8,7,6};
    forward_list<int> l13 = {};
    cout << "The two lists for list copy: " <<endl <<
    "(10,9,8,7,6)" << endl << "(no numbers)" << endl;
    cout << "The list copied: ";
    listCopy(l12,l13);
    cout << endl;
    
    cout << "Part Number 4." << endl;
    forward_list<int> l3 = {1,3,4,7};
    cout<< "Int List (1,3,4,7) " << endl;
    forward_list<int> l4 = {0,1,2,3,4,5,6,7};
    cout<< "Of any type List (0,1,2,3,4,5,6,7) " << endl;
    cout<< "Using print lots function: " << endl;
    printLots(l4,l3);
    cout<< "Getting an error by trying the other way around:" << endl;
    printLots(l3,l4);
    forward_list<int> l8 = {0,2,6};
    cout<< "Int List (0,2,6) " << endl;
    forward_list<int> l9 = {2,4,5,32,67,73,97,106};
    cout<< "Of any type List (2,4,5,32,67,73,97,106) " << endl;
    cout<< "Using print lots function: " << endl;
    printLots(l9,l8);
    cout<< "Getting an error by trying the other way around:" << endl;
    printLots(l8,l9);
    cout << endl;
}