//Name: Jeremy Chan SID: 861169589 date: 4/19/2015
//Lecturer: Jacobs Lab Director: Dingwen

#include "lab3.h"
#include <iostream>
#include <string>
#include <stack>

int main ()
{
    cout << "Part 1." << endl;
    cout << "Creats a fixed stack of size 5 and a partition at index 2." <<endl;
    cout << "Checks popping of stacks when empty." <<endl;
    TwoStackFixed<int> i(5,2);
    i.popStack1();
    i.popStack2();
    cout << "Will then fill both sides first by 6, then 5." <<endl;
    i.pushStack1(6);
    i.pushStack2(6);
    i.pushStack1(5);
    i.pushStack2(5);
    cout << "Pushes 4 into index 2 for stack 1." <<endl;
    i.pushStack1(4);//no problems up to this point
    cout << "Causes an error when more is pushed on either side." <<endl;
    i.pushStack2(3);
    i.pushStack1(3);
    
    cout << "Pops 2 vals from stack 1: " << endl;
    i.popStack1();
    i.popStack1();
    cout << "Causes an error when trying to push more on stack 3"
    << " due to partition." <<endl;
    i.pushStack2(3);
    
    cout << "Pops last value in stack 2 and pushes a 4 onto stack 1." << endl;
    i.popStack2();
    i.pushStack1(4);
    
    cout << endl << endl << "Part 2.";
    
    cout << "Creats an optimal stack of size 5." <<endl;
    cout << "Checks popping of stacks when empty." <<endl;
    TwoStackOptimal<int> h(5);
    h.popFlexStack1();
    h.popFlexStack2();
    cout << "Will then fill both sides first by 6, then 5." <<endl;
    h.pushFlexStack1(6);
    h.pushFlexStack2(6);
    h.pushFlexStack1(5);
    h.pushFlexStack2(5);
    cout << "Pushes 4 into index 2 for stack 1." <<endl;
    h.pushFlexStack1(4);
    cout <<"Tries to push 4 for stack 2 but there is no more space in array"
    << endl;
    h.pushFlexStack2(4);
    
    cout << "Pops value for stack 1 and pushes a 3 for stack 2"
    << "(valid since no partition)" << endl;
    h.popFlexStack1();
    h.pushFlexStack2(3);
    
    cout << "Pops value for stack 2 and pushes a 4 for stack 1"
    << "(same as previous)" << endl;
    h.popFlexStack2();
    h.pushFlexStack1(4);
    
    cout << endl << endl << "Part 3.";
    cout << "Created 3 stacks A,B,C and pushed 3 then 2 then "
     << "1 onto the first stack.(It will print movements of disks)" << endl;
    stack<int> A, B, C;
    A.push(3);
    A.push(2);
    A.push(1);
    showTowerStates(3,A,B,C);
}