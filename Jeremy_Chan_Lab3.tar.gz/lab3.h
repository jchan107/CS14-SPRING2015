//Name: Jeremy Chan SID: 861169589 date: 4/19/2015
//Lecturer: Jacobs Lab Director: Dingwen

#ifndef _LAB3_H_
#define _LAB3_H_

#include <iostream>
#include <string>
#include <stack>


using namespace std;

void print(int n, char a, char b, char c)//this is used to print out the steps shown in moving disks
{
    if(n== 1)//base case
    {
        cout << "Moved " << n << " from peg " << a << " to peg " << c << endl;
    }
    else if (n > 1)
    {
        print (n-1, a,c,b);
        cout << "Moved " << n << " from peg " << a << " to peg " << c << endl;
        print (n-1, c,b,a);
    }
}

template <typename T>
void movingDisks(int n, stack<T>& A,stack<T>& B, stack<T>& C)//does the actual moving of the disks
{
    if(n == 1)//base case
    {
        T i = A.top();
        A.pop();
        C.push(i);
        return;
    }
    else
    {
        movingDisks(n - 1, A,C,B);
        T i = A.top();
        A.pop();
        C.push(i);
        movingDisks(n - 1, C,B,A);
    }
}

template <typename T>
void showTowerStates(int n, stack<T>& A,stack<T>& B, stack<T>& C)//just used to call the 2 helper functions
{
    print(n,'A','B','C');
    movingDisks(n,A,B,C);
}

template <class T>
class TwoStackOptimal
{
   private:
    T* stackH = new T[1];//holds the array
    int aSize,currS1,currS2;//holds the array size and the sizes of the 2 stacks
   public:
    TwoStackOptimal(int size); 
    void pushFlexStack1(T value); 
    void pushFlexStack2(T value); 
    T popFlexStack1(); 
    T popFlexStack2(); 
   private:
    bool isFullStack1();
    bool isFullStack2();
    bool isEmptyStack1();
    bool isEmptyStack2();
    void display();
};

template <class T>
TwoStackOptimal<T>::TwoStackOptimal(int size)
{
    currS1 = 0;
    currS2 = 0;
    aSize = size;
    T* temp = new T[size];
    for(int i = 0; i < size; i++)
    {
        temp[i] = 0;
    }
    delete stackH;
    stackH = temp;
}

template <class T>
void TwoStackOptimal<T>::pushFlexStack1(T value)
{
    if(isFullStack1())//sees if array is already full
    {
        cout << "Cannot add anymore to stack 1." << endl;
        return;
    }
    if(isEmptyStack1())
    {
        stackH[0] = value;
        currS1++;
        display();
        return;
    }
    
    stackH[currS1] = value;
    currS1++;
    display();
}

template <class T>
void TwoStackOptimal<T>::pushFlexStack2(T value)
{
    if(isFullStack2())//makes sure the array is not full of values
    {
        cout << "Cannot add anymore to stack 2." << endl;
        return;
    }
    if(isEmptyStack2())
    {
        stackH[aSize - 1] = value;//has to start at opposite end
        currS2++;
        display();
        return;
    }
    
    stackH[aSize - currS2 - 1] = value;
    currS2++;
    display();
}

template <class T>
T TwoStackOptimal<T>::popFlexStack1()
{
    T temp;
    if(isEmptyStack1())//makes sure it isnt popping from empty stack
    {
        cout << "Nothing to be popped from stack 1." << endl;
        temp = 0;
        return temp;
    }
    
    temp = stackH[currS1 - 1];
    cout << stackH[currS1 - 1] << endl;
    stackH[currS1 - 1] = ' ';
    currS1--;
    return temp;
}

template <class T>
T TwoStackOptimal<T>::popFlexStack2()
{
    T temp;
    if(isEmptyStack2())//makes sure it isnt popping an empty stack
    {
        cout << "Nothing to be popped from stack 2." << endl;
        temp = 0;
        return temp;
    }
    
    temp = stackH[aSize - currS2];//goes reverse from stack one so it has to start at the end
    cout << stackH[aSize - currS2] << endl;
    stackH[aSize - currS2] = ' ';
    currS2--;
    return temp;
}

template <class T>
bool TwoStackOptimal<T>::isFullStack1()//same as function isFullStack2
{
    if(currS1 + currS2 == aSize)
    {
        return true;
    }
    return false;
}

template <class T>
bool TwoStackOptimal<T>::isFullStack2()//since no bounds, checks to see if full array is already used
{
    if(currS1 + currS2 == aSize)
    {
        return true;
    }
    return false;
}

template <class T>
bool TwoStackOptimal<T>::isEmptyStack1()
{
    if(currS1 == 0)
    {
        return true;
    }
    return false;
}

template <class T>
bool TwoStackOptimal<T>::isEmptyStack2()
{
    if(currS2 == 0)
    {
        return true;
    }
    return false;
}

template <class T>
void TwoStackOptimal<T>::display()
{
    for(int i = 0; i < aSize; i++)
    {
        cout << stackH[i] << " ";
    }
    cout << endl;
}

template <class T>
class TwoStackFixed
{
   private:
    T* stackH = new T[1];
    int stackP;
    int aSize,currS1,currS2;//holds array size, and each stack's size
   public:
    TwoStackFixed(int size, int maxtop ); 
    void pushStack1(T value); 
    void pushStack2(T value); 
    T popStack1(); 
    T popStack2(); 
   private:
    bool isFullStack1();
    bool isFullStack2();
    bool isEmptyStack1();
    bool isEmptyStack2();
    void display();
};

template <class T>
TwoStackFixed<T>::TwoStackFixed(int size, int maxtop )
{
    currS1 = 0;
    currS2 = 0;
    aSize = size;
    T* temp = new T[size];
    for(int i = 0; i < size; i++)
    {
        temp[i] = 0;
    }
    delete stackH;
    stackH = temp;//creates new array with size given by user
    stackP = maxtop;
}

template <class T>
void TwoStackFixed<T>::pushStack1(T value)
{
    if(isFullStack1())
    {
        cout << "Cannot add anymore to stack 1." << endl;
        return;
    }
    if(isEmptyStack1())
    {
        stackH[0] = value;
        currS1++;
        display();
        return;
    }
    
    stackH[currS1] = value;//adds a value to the stack
    currS1++;//makes size of stack 1 greater
    display();
}

template <class T>
void TwoStackFixed<T>::pushStack2(T value)
{
    if(isFullStack2())//if full you do nothing
    {
        cout << "Cannot add anymore to stack 2." << endl;
        return;
    }
    if(isEmptyStack2())//checks if size of stack is 0
    {
        stackH[aSize - 1] = value;
        currS2++;
        display();
        return;
    }
    
    stackH[aSize - currS2 - 1] = value;
    currS2++;
    display();
}

template <class T>
T TwoStackFixed<T>::popStack1()
{
    T temp;
    if(isEmptyStack1())
    {
        cout << "Nothing to be popped from stack 1." << endl;
        temp = 0;
        return temp;
    }
    
    temp = stackH[currS1 - 1];
    cout << stackH[currS1 - 1] << endl;//outputs the value
    stackH[currS1 - 1] = 0;
    currS1--;//makes size smaller
    return temp;
}

template <class T>
T TwoStackFixed<T>::popStack2()
{
    T temp;
    if(isEmptyStack2())//makes sure stack isnt empty
    {
        temp = 0;
        cout << "Nothing to be popped from stack 2." << endl;
        return temp;
    }
    
    temp = stackH[aSize - currS2];
    cout << stackH[aSize - currS2] << endl;
    stackH[aSize - currS2] = 0;
    currS2--;
    return temp;
}

template <class T>
bool TwoStackFixed<T>::isFullStack1()
{
    if(currS1 - 1 == stackP)
    {
        return true;
    }
    return false;
}

template <class T>
bool TwoStackFixed<T>::isFullStack2()//checks to see the last index of stack 2
{
    if(aSize - currS2 - 1== stackP)
    {
        return true;
    }
    return false;
}

template <class T>
bool TwoStackFixed<T>::isEmptyStack1()
{
    if(currS1 == 0)
    {
        return true;
    }
    return false;
}

template <class T>
bool TwoStackFixed<T>::isEmptyStack2()
{
    if(currS2 == 0)
    {
        return true;
    }
    return false;
}

template <class T>
void TwoStackFixed<T>::display()
{
    for(int i = 0; i < aSize; i++)
    {
        cout << stackH[i] << " ";
    }
    cout << endl;
}
#endif