//Name: Jeremy Chan SID: 861169589 date: 4/19/2015
//Lecturer: Jacobs Lab Director: Dingwen
//Approach:to make the selection sort, i used an iterator that will serve as the reference point,
//another iterator to store the lowest value after the reference point
//and a last iterator to traverse all of the list, or vector, past the initial reference point.
//the loop will then exchange the values of the reference iterator and the one
//that kept the lowest val only if this lowest val iterator is less than the initial one.
//This will then sort the list in ascending order.
#ifndef _SELECTIONSORT_H_
#define _SELECTIONSORT_H_

#include <iostream>

using namespace std;

template<typename L>
void display(L &l)//the display function for non-pair lists or vectors
{
    for(auto r1 = l.begin();r1 != l.end();r1++)
    {
        cout << *r1 << " ";
    }
    cout << endl;
}

template<typename L>
void display2(L &l)//the display function for pair vectors
{
    for(auto r1 = l.begin();r1 != l.end();r1++)
    {
        cout << "("<< r1->first << "," << r1->second << ")" << " ";//writes it in this format: "(5,5)"
    }
    cout << endl;
}

template<typename L>
void selectionsort(L &l)
{
    int numMoves = 0;//counts num of moves
    if(l.size() <= 1)//if size is zero or one than you dont have to sort anything
    {
        return;
    }
    
    
    for(auto r1 = l.begin();r1 != l.end();r1++)//r1 is the reference point. It is what is going to be swapped if r2 is lower 
    {
        auto r2 = r1;
        r2++;//r2 begins at the next iteration after r1
        if(r2 != l.end())
        {
            for(auto temp = r2; temp != l.end();temp++)//temp goes through the rest of the list or vector
            {
                if(*temp < *r2)//looking to find the smallest value
                {
                    r2 = temp;//by the end of the for loop r2 will be the smallest value past r1
                }
            }
            if(*r2 < *r1)//need to swap only if r2 is less than r1
            {
                numMoves++;// adds 1 to num of moves but in the end we have to multiply by 3 because swap takes 3 moves
                swap(*r1,*r2);
            }
        }
    }
    cout << "0 copies and " << numMoves *3 << " moves" << endl;//prints num of moves after the whole for loop is finished
}


#endif
