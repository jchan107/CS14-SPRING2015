//Name: Jeremy Chan SID: 861169589 date: 4/19/2015
//Lecturer: Jacobs Lab Director: Dingwen
#include <iostream>
#include <vector>
#include <list>
#include "selectionsort.h"

using namespace std;


int main ()
{
    cout << "Checking to see if the sort is stable." << endl;
    
    vector<pair<int, int> > l6;
    l6.push_back(make_pair(0,3));
    l6.push_back(make_pair(0,0));
    cout << "Pre: ";
    display2(l6);
    selectionsort(l6);
    cout << "Post: ";
    display2(l6);
    
    cout << endl;
}