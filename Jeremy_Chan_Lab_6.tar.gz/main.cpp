//Name: Jeremy Chan SID: 861169589 date: 4/19/2015
//Lecturer: Jacobs Lab Director: Dingwen
#include <iostream>
#include <vector>
#include <list>
#include "selectionsort.h"

using namespace std;


int main ()
{
    
    list<int> l1;
    l1.push_back(2);
    l1.push_back(4);
    l1.push_back(5);
    l1.push_back(1);
    l1.push_back(8);
    l1.push_back(9);
    cout << "Pre: ";
    display(l1);
    selectionsort(l1);
    cout << "Post: ";
    display(l1);
    
    cout << endl;
    
    vector<int> l2;
    cout << "Pre: ";
    display(l2);
    selectionsort(l2);
    cout << "Post: ";
    display(l2);
    
    cout << endl;
    
    vector<pair<int, int> > l3;
    l3.push_back(make_pair(1,2));
    l3.push_back(make_pair(3,-1));
    l3.push_back(make_pair(-1,3));
    l3.push_back(make_pair(0,0));
    l3.push_back(make_pair(2,3));
    l3.push_back(make_pair(1,2));
    l3.push_back(make_pair(1,-2));
    l3.push_back(make_pair(8,10));
    cout << "Pre: ";
    display2(l3);
    selectionsort(l3);
    cout << "Post: ";
    display2(l3);
    
    cout << endl;
    
    vector<pair<int, int> > l4;
    l4.push_back(make_pair(10,2));
    l4.push_back(make_pair(-3,-1));
    l4.push_back(make_pair(-8,0));
    l4.push_back(make_pair(1,1));
    l4.push_back(make_pair(1,1));
    l4.push_back(make_pair(0,0));
    l4.push_back(make_pair(10,2));
    l4.push_back(make_pair(5,5));
    l4.push_back(make_pair(5,-5));
    l4.push_back(make_pair(0,0));
    l4.push_back(make_pair(10,2));
    cout << "Pre: ";
    display2(l4);
    selectionsort(l4);
    cout << "Post: ";
    display2(l4);
    
    cout << endl;
    
    vector<pair<int, int> > l5;
    l5.push_back(make_pair(-1,3));
    l5.push_back(make_pair(0,0));
    l5.push_back(make_pair(1,-2));
    l5.push_back(make_pair(1,2));
    l5.push_back(make_pair(1,2));
    l5.push_back(make_pair(2,3));
    l5.push_back(make_pair(3,-1));
    l5.push_back(make_pair(8,10));
    cout << "Pre: ";
    display2(l5);
    selectionsort(l5);
    cout << "Post: ";
    display2(l5);
    
    cout << endl;
    
    cout << "Checking to see if the sort is stable." << endl;
    
    vector<pair<int, int> > l6;
    l6.push_back(make_pair(0,3));
    l6.push_back(make_pair(0,0));
    cout << "Pre: ";
    display2(l6);
    selectionsort(l6);
    cout << "Post: ";
    display2(l6);
    
    cout << endl;
    
    list<int> l7;
    l7.push_back(2);
    l7.push_back(2);
    cout << "Pre: ";
    display(l7);
    selectionsort(l7);
    cout << "Post: ";
    display(l7);
    
    cout << endl;
}