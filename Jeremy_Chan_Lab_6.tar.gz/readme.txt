//Name: Jeremy Chan SID: 861169589 date: 4/19/2015
//Lecturer: Jacobs Lab Director: Dingwen

Selection sort (at least my version of it) is not stable. This can be seen in 
the two tests run by proof.cpp. In the first test, i pushed in the pair 0,3 then
0,0. Since the the < operator compares the first 2 digits and they are equal,
it is apparent that this sort is not stable because the values are switched when
selection sort is called. 

